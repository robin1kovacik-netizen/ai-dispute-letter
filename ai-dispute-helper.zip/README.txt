# AI Dispute Helper — Quick Start Guide (iPhone Friendly)

**Purpose:** This folder contains your free website for "Build Your Own Credit Dispute Letter with AI".
You can publish it online for free using GitHub Pages — no cost or domain needed.

---

## 📱 How to Upload on iPhone (GitHub Pages)

1. **Open Safari** → go to [https://github.com](https://github.com) and **sign in**.
2. Tap the **+** → “New Repository” → name it **ai-dispute-helper** → leave it **Public** → tap **Create repository**.
3. On the new repo page, tap **Add file → Upload files**.
4. Tap **Choose Files**, then select these files from your **Files app** (unzip this ZIP first).
   - index.html
   - templates.html
   - assets/ (folder if possible)
   - README.txt
5. Tap **Commit changes** to finish uploading.
6. Go to your repo **Settings → Pages**, under “Source” choose “main branch”, and tap **Save**.
7. Wait 1–2 minutes — your site will be live at:  
   👉 **https://yourusername.github.io/ai-dispute-helper**

---

## 🧾 Using the Site
- Open the link above to view your website.  
- Use the **Letter Generator** to fill in your details.  
- Tap “Download PDF” (it opens the iOS print menu → choose **Save to Files** to keep a PDF).

---

## 💰 Adding Ads or Affiliate Links Later
Inside the HTML you’ll find `<div class="ad-placeholder">` sections. Replace those with code from:
- **Google AdSense**
- **Affiliate programs** (Credit Karma, Experian, etc.)

---

✅ You now own a working AI-based credit dispute helper website!
